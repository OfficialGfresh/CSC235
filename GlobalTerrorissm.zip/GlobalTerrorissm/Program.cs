﻿using System;
using System.Collections.Generic;
using System.IO;

namespace TerroristSum
{
    class Program
    {
        static void Main(string[] args)
        {
            // define a dictionary to store the sums of each row
            Dictionary<int, List<int[]>> sums = new Dictionary<int, List<int[]>>();

            // open the file
            using (StreamReader file = new StreamReader("terrorist.txt"))
            {
                // read each line in the file
                string line;
                while 
                (line = file.ReadLine()!= null);
                line = Convert.ToString(line);





                {
                    // split the line into a list of features
                    string[] features = line.Split(",");
                    // convert the features to integers
                    int[] intFeatures = Array.ConvertAll(features, int.Parse);
                    // calculate the sum of the features
                    int featureSum = intFeatures.Sum();
                    // check if the sum already exists in the dictionary
                    if (sums.ContainsKey(featureSum))
                    {
                        // if it does, add the current line to the list of lines with the same sum
                        sums[featureSum].Add(intFeatures);
                    }
                    else
                    {
                        // if it doesn't, create a new entry in the dictionary with the current line
                        sums[featureSum] = new List<int[]>() { intFeatures };
                    }
                }
            }

            // print the results
            foreach (KeyValuePair<int, List<int[]>> entry in sums)
            {
                Console.WriteLine($"Lines with sum {entry.Key}:");
                foreach (int[] line in entry.Value)
                {
                    Console.WriteLine(string.Join(", ", line));
                }
            }
        }
    }
}